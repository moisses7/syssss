require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

const casos = [
  {
    id: 'CASO-001',
    tipoInfraestructura: 'Casa',
    tipoAfectacion: 'pared_caida',
    categoriaDano: 'Roja',
    ubicacion: { municipio: 'Peña', sector: 'Camino Nuevo', calle: 'Calle La Pastora', numero: 'Nro 45' },
    inspeccion: { realizada: 'si', organo: 'Bomberos', funcionario: 'Juan Pérez' },
    coordenadas: { lat: 10.0784, lng: -69.1219 },
    fotos: ['/fotos/1.jpeg'],
    propietario: { nombres: 'Yuriannys', apellidos: 'Fernandez', cedula: 'V-26741835', telefono: '0414-1234567', correo: 'cmendoza@email.com', estatusRefugio: 'en_refugio', dano: 'Golpe en la cabeza', medicina: 'Analgésicos', requiereAsistenciaMedica: true },
    habitantes: []
  },
  {
    id: 'CASO-002',
    tipoInfraestructura: 'Edificio',
    tipoAfectacion: 'grieta_pronunciada',
    categoriaDano: 'Amarilla',
    ubicacion: { municipio: 'San Felipe', sector: 'Centro', calle: 'Av. Caracas', numero: 'Edificio Araguaney, Apto 3B' },
    inspeccion: { realizada: 'no', organo: '', funcionario: '' },
    coordenadas: { lat: 10.3396, lng: -68.7351 },
    fotos: ['/logo.png'],
    propietario: { nombres: 'Luisa Elena', apellidos: 'Giménez', cedula: 'V-15987654', telefono: '0424-9876543', correo: 'luisag@email.com', estatusRefugio: 'sin_necesidad', dano: '', medicina: '', requiereAsistenciaMedica: false },
    habitantes: []
  },
  {
    id: 'CASO-003',
    tipoInfraestructura: 'Casa',
    tipoAfectacion: 'grieta_superficial',
    categoriaDano: 'Verde',
    ubicacion: { municipio: 'Bruzual', sector: 'Centro', calle: 'Calle 9', numero: '12-A' },
    inspeccion: { realizada: 'si', organo: 'Bomberos', funcionario: 'Pedro Ruiz' },
    coordenadas: { lat: 10.1581, lng: -68.8967 },
    fotos: ['https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=400'],
    propietario: { nombres: 'Pedro', apellidos: 'Castillo', cedula: 'V-9876543', telefono: '0412-5556677', correo: 'pcastillo@email.com', estatusRefugio: 'sin_refugio', dano: '', medicina: '', requiereAsistenciaMedica: false },
    habitantes: [{ id: 1, nombres: 'Ana', apellidos: 'Castillo', cedula: 'V-29876543', dano: 'Ninguno', medicina: 'Ninguna', requiereAsistenciaMedica: false }]
  }
];

async function seed() {
  await pool.query('BEGIN');
  for (const caso of casos) {
    await pool.query(`
      INSERT INTO casos_siged (id, tipo_infraestructura, tipo_afectacion, categoria_dano, ubicacion, inspeccion, coordenadas, fotos, propietario, habitantes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      ON CONFLICT (id) DO NOTHING
    `, [
      caso.id, caso.tipoInfraestructura, caso.tipoAfectacion, caso.categoriaDano,
      caso.ubicacion, caso.inspeccion, caso.coordenadas, JSON.stringify(caso.fotos),
      caso.propietario, JSON.stringify(caso.habitantes)
    ]);
  }
  await pool.query('COMMIT');
  console.log('Base de datos poblada con datos de ejemplo.');
  pool.end();
}

seed().catch(e => { console.error(e); pool.end(); });
