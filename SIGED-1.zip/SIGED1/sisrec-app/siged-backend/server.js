require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();

app.use(cors());
app.use(express.json({ limit: '50mb' }));

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

app.get('/api/casos', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM casos_siged ORDER BY fecha_registro ASC');
    const casos = result.rows.map(row => ({
      id: row.id,
      tipoInfraestructura: row.tipo_infraestructura,
      tipoAfectacion: row.tipo_afectacion,
      categoriaDano: row.categoria_dano,
      ubicacion: row.ubicacion,
      inspeccion: row.inspeccion,
      coordenadas: row.coordenadas,
      fotos: row.fotos || [],
      propietario: row.propietario,
      habitantes: row.habitantes || []
    }));
    res.json(casos);
  } catch (error) {
    console.error("Error al obtener casos:", error);
    res.status(500).json({ error: 'Error del servidor' });
  }
});

app.post('/api/casos', async (req, res) => {
  const casos = Array.isArray(req.body) ? req.body : [req.body];
  try {
    await pool.query('BEGIN');
    for (const caso of casos) {
      const text = `
        INSERT INTO casos_siged 
        (id, tipo_infraestructura, tipo_afectacion, categoria_dano, ubicacion, inspeccion, coordenadas, fotos, propietario, habitantes) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      `;
      const values = [
        caso.id, caso.tipoInfraestructura, caso.tipoAfectacion, caso.categoriaDano,
        caso.ubicacion, caso.inspeccion, caso.coordenadas, JSON.stringify(caso.fotos),
        caso.propietario, JSON.stringify(caso.habitantes)
      ];
      await pool.query(text, values);
    }
    await pool.query('COMMIT');
    res.status(201).json({ message: 'Registros creados con éxito' });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error("Error al guardar:", error);
    res.status(500).json({ error: 'Error al insertar en la base de datos' });
  }
});

app.put('/api/casos/:id', async (req, res) => {
  const { id } = req.params;
  const caso = req.body;
  try {
    const text = `
      UPDATE casos_siged SET 
        tipo_infraestructura = $1, tipo_afectacion = $2, categoria_dano = $3, 
        ubicacion = $4, inspeccion = $5, coordenadas = $6, fotos = $7, 
        propietario = $8, habitantes = $9
      WHERE id = $10
    `;
    const values = [
      caso.tipoInfraestructura, caso.tipoAfectacion, caso.categoriaDano,
      caso.ubicacion, caso.inspeccion, caso.coordenadas, JSON.stringify(caso.fotos),
      caso.propietario, JSON.stringify(caso.habitantes), id
    ];
    await pool.query(text, values);
    res.json({ message: 'Caso actualizado' });
  } catch (error) {
    console.error("Error al actualizar:", error);
    res.status(500).json({ error: 'Error al actualizar el registro' });
  }
});

app.delete('/api/casos/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM casos_siged WHERE id = $1', [req.params.id]);
    res.json({ message: 'Caso eliminado correctamente' });
  } catch (error) {
    console.error("Error al eliminar:", error);
    res.status(500).json({ error: 'Error al eliminar el registro' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Backend de SIGED activo y escuchando en el puerto ${PORT}`);
});
