import { useState, useEffect, useMemo, useRef } from 'react';
import { 
  AlertTriangle, 
  MapPin, 
  Home, 
  Users, 
  FileText, 
  Camera, 
  Plus, 
  X, 
  CheckCircle,
  Download,
  List,
  Map as MapIcon,
  Search,
  Filter,
  Pencil,
  Trash2
} from 'lucide-react';

// --- TIPOS GLOBALES Y DECLARACIONES ---
declare global {
  interface Window {
    L: any; // Permite el uso de Leaflet inyectado globalmente
  }
}



const MUNICIPIOS_YARACUY = [
  'Aristides Bastidas', 'Bolívar', 'Bruzual', 'Cocorote', 'Independencia', 
  'José Antonio Páez', 'La Trinidad', 'Manuel Monge', 'Nirgua', 'Peña', 
  'San Felipe', 'Sucre', 'Urachiche', 'Veroes'
];

// Metodología ATC-20 aplicada a las opciones rápidas
const TIPOS_AFECTACION = [
  { id: 'grieta_superficial', label: 'Grieta Superficial (Daño Leve)', categoria: 'Verde' },
  { id: 'grieta_pronunciada', label: 'Grieta Pronunciada (Daño Moderado)', categoria: 'Amarilla' },
  { id: 'ruptura_pared', label: 'Ruptura de Pared', categoria: 'Amarilla' },
  { id: 'pared_caida', label: 'Pared Caída / Falla por Cortante', categoria: 'Roja' },
  { id: 'viga_caida', label: 'Viga Caída / Colapso Parcial', categoria: 'Roja' },
  { id: 'colapso_total', label: 'Colapso Total / Peligro Inminente', categoria: 'Roja' }
];

export default function App() {
  const [cases, setCases] = useState<any[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<any | null>(null);
  const [leafletReady, setLeafletReady] = useState(false);
  const [currentView, setCurrentView] = useState<'map' | 'list'>('map');
  const [editingCaseId, setEditingCaseId] = useState<string | null>(null);

  const fetchCasosDesdeSQL = async () => {
    try {
      const response = await fetch('/api/casos');
      if (!response.ok) throw new Error("Error en red");
      const data = await response.json();
      setCases(data);
    } catch (error) {
      console.error("Error conectando al backend:", error);
    }
  };

  useEffect(() => {
    fetchCasosDesdeSQL();
  }, []);

  useEffect(() => {
    if (!document.getElementById('leaflet-css')) {
      const link = document.createElement('link');
      link.id = 'leaflet-css';
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }
    if (!document.getElementById('leaflet-js')) {
      const script = document.createElement('script');
      script.id = 'leaflet-js';
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => setLeafletReady(true);
      document.head.appendChild(script);
    } else {
      setLeafletReady(true);
    }
  }, []);

  const handleSaveCase = async (nuevosCasos: any) => {
    let payload = Array.isArray(nuevosCasos) ? nuevosCasos : [nuevosCasos];

    if (editingCaseId) {
      const casoActualizado = { ...payload[0], id: editingCaseId };
      try {
        await fetch(`/api/casos/${editingCaseId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(casoActualizado)
        });
      } catch (error) {
        console.error("Error al actualizar:", error);
      }
    } else {
      payload = payload.map((nc: any, i: number) => ({
        ...nc,
        id: `CASO-${String(cases.length + i + 1).padStart(3, '0')}`
      }));
      try {
        await fetch('/api/casos', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (error) {
        console.error("Error al crear:", error);
      }
    }

    await fetchCasosDesdeSQL();
    setIsFormOpen(false);
    setEditingCaseId(null);
    if(currentView === 'list') setCurrentView('map');
  };

  const handleSelectCaseFromList = (caseItem: any) => {
    setSelectedCase(caseItem);
    setCurrentView('map');
  };

  const handleEditCase = (caseItem: any) => {
    setEditingCaseId(caseItem.id);
    setIsFormOpen(true);
  };

  const handleDeleteCase = async (caseItem: any) => {
    if (window.confirm(`¿Está seguro de eliminar el caso ${caseItem.id} de la base de datos?`)) {
      try {
        await fetch(`/api/casos/${caseItem.id}`, {
          method: 'DELETE'
        });
        await fetchCasosDesdeSQL();
        if (selectedCase?.id === caseItem.id) {
          setSelectedCase(null);
        }
      } catch (error) {
        console.error("Error al eliminar:", error);
      }
    }
  };

  const handleExport = () => {
    const total = cases.length;
    const etiquetaRoja = cases.filter((c: any) => c.categoriaDano === 'Roja').length;
    const etiquetaAmarilla = cases.filter((c: any) => c.categoriaDano === 'Amarilla').length;
    const etiquetaVerde = cases.filter((c: any) => c.categoriaDano === 'Verde').length;
    const conInspeccion = cases.filter((c: any) => c.inspeccion.realizada === 'si').length;
    const sinInspeccion = cases.filter((c: any) => c.inspeccion.realizada === 'no').length;

    let htmlContent = `
      <html>
        <head>
          <title>Reporte de Casos-SIGED Yaracuy</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; color: #333; }
            h1 { color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; }
            h2 { color: #1e293b; margin-top: 30px; }
            .stats-container { display: flex; gap: 20px; margin-bottom: 40px; }
            .stat-box { border: 1px solid #cbd5e1; padding: 15px; border-radius: 8px; flex: 1; background: #f8fafc; }
            .case-card { border: 1px solid #cbd5e1; padding: 15px; margin-bottom: 20px; border-radius: 8px; }
            .case-card h3 { margin-top: 0; color: #b91c1c; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #e2e8f0; padding: 8px; text-align: left; font-size: 14px; }
            th { background-color: #f1f5f9; width: 25%; }
            .rojo { color: #dc2626; font-weight: bold; }
            .amarillo { color: #d97706; font-weight: bold; }
            .verde { color: #16a34a; font-weight: bold; }
          </style>
        </head>
        <body>
          <h1>Reporte General de Afectaciones (Metodología ATC-20) - SIGED Yaracuy</h1>
          
          <div class="stats-container">
            <div class="stat-box">
              <h2 style="margin-top: 0; font-size: 18px;">Clasificación de Daños</h2>
              <p><strong>Total Estructuras Registradas:</strong> ${total}</p>
              <p class="rojo">Inhabitable: ${etiquetaRoja}</p>
              <p class="amarillo">Restringido: ${etiquetaAmarilla}</p>
              <p class="verde">Habitable (Daño Leve): ${etiquetaVerde}</p>
            </div>
            <div class="stat-box">
              <h2 style="margin-top: 0; font-size: 18px;">Estado de Inspecciones</h2>
              <p><strong>Inspecciones Realizadas:</strong> ${conInspeccion}</p>
              <p><strong>Pendientes de Revisión:</strong> ${sinInspeccion}</p>
            </div>
          </div>

          <h2>Detalle de Casos Registrados</h2>
    `;

    cases.forEach((c: any) => {
      let habitantesTexto = c.habitantes && c.habitantes.length > 0 
        ? c.habitantes.map((h: any) => h.nombres + ' ' + h.apellidos + (h.dano ? ' (Lesión: ' + h.dano + ')' : '') + (h.requiereAsistenciaMedica ? ' [ASISTENCIA MÉDICA]' : '')).join(', ') 
        : 'Ninguno';

      let propietarioSalud = '';
      if(c.propietario.dano || c.propietario.medicina || c.propietario.requiereAsistenciaMedica) {
        propietarioSalud = `<tr><th colspan="4" style="background-color: #fee2e2; color: #991b1b;">Salud Responsable: ${c.propietario.dano ? 'Lesión: '+c.propietario.dano+'; ' : ''} ${c.propietario.medicina ? 'Requiere: '+c.propietario.medicina+'; ' : ''} ${c.propietario.requiereAsistenciaMedica ? '¡REQUIERE ASISTENCIA MÉDICA INMEDIATA!' : ''}</th></tr>`;
      }

      htmlContent += '<div class="case-card">' +
        '<h3>' + c.id + ' - ' + c.ubicacion.municipio + ' (Etiqueta ' + c.categoriaDano + ')</h3>' +
        '<table>' +
          '<tr><th>Tipo de Infraestructura</th><td>' + c.tipoInfraestructura + '</td><th>Tipo de Afectación</th><td style="text-transform: capitalize;">' + c.tipoAfectacion.replace('_', ' ') + '</td></tr>' +
          '<tr><th>Ubicación Exacta</th><td colspan="3">Sector ' + c.ubicacion.sector + ', Calle/Av ' + c.ubicacion.calle + ', ' + c.ubicacion.numero + '</td></tr>' +
          '<tr><th>Inspección Realizada</th><td colspan="3">' + (c.inspeccion.realizada === 'si' ? 'Sí (Organismo: ' + c.inspeccion.organo + ' | Funcionario: ' + c.inspeccion.funcionario + ')' : 'No') + '</td></tr>' +
          '<tr><th>Datos del Responsable</th><td>' + c.propietario.nombres + ' ' + c.propietario.apellidos + '</td><th>Cédula</th><td>' + c.propietario.cedula + '</td></tr>' +
          '<tr><th>Teléfono</th><td>' + c.propietario.telefono + '</td><th>Estatus de Refugio</th><td style="text-transform: capitalize;">' + c.propietario.estatusRefugio.replace(/_/g, ' ') + '</td></tr>' +
          propietarioSalud +
          '<tr><th>Otros / Familiares (' + (c.habitantes ? c.habitantes.length : 0) + ')</th><td colspan="3">' + habitantesTexto + '</td></tr>' +
        '</table>' +
      '</div>';
    });

    htmlContent += `
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 250);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800">
      {/* Header */}
      <header className="bg-slate-900 text-white p-4 shadow-md top-0 z-40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <button 
            onClick={() => { setSelectedCase(null); setCurrentView('map'); }} 
            className="flex items-center space-x-3 text-left hover:opacity-80 transition-opacity focus:outline-none w-full md:w-auto"
            title="Volver al inicio"
          >
            <img src="/icono.svg" className="w-16 h-16"/>
            <div>
              <h1 className="text-xl font-bold leading-tight">SIGED YARACUY</h1>
              <p className="text-xs text-slate-400">Sistema de Gestión y Evaluación de Daños</p>
            </div>
          </button>
          
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
            <button 
              onClick={() => setCurrentView(currentView === 'map' ? 'list' : 'map')}
              className="bg-slate-800 border border-slate-700 hover:bg-slate-700 text-white px-4 py-2 rounded-md flex items-center font-semibold transition-colors shadow-sm"
            >
              {currentView === 'map' ? (
                <><List className="w-5 h-5 mr-2" /> <span className="hidden sm:inline">Ver Lista</span></>
              ) : (
                <><MapIcon className="w-5 h-5 mr-2" /> <span className="hidden sm:inline">Ver Mapa</span></>
              )}
            </button>
            <button 
              onClick={handleExport}
              className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-md flex items-center font-semibold transition-colors shadow-sm"
            >
              <Download className="w-5 h-5 mr-2" />
              <span className="hidden sm:inline">Exportar</span>
            </button>
            <button 
              onClick={() => setIsFormOpen(true)}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md flex items-center font-semibold transition-colors shadow-sm"
            >
              <Plus className="w-5 h-5 mr-2" />
              <span className="hidden sm:inline">Registrar Caso</span>
              <span className="sm:hidden">Registrar</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 flex flex-col gap-6">
        <DashboardStats cases={cases} />
        
        {currentView === 'map' ? (
          <div className="flex flex-col lg:flex-row gap-6 h-[600px] fade-in">
            <div className="flex-grow bg-white rounded-xl shadow-sm overflow-hidden border border-slate-200 relative">
               <div className="absolute top-4 left-4 z-10 bg-white/90 p-3 rounded-md shadow-md text-xs font-semibold backdrop-blur-sm pointer-events-none">
                  <div className="flex items-center gap-2 mb-1"><span className="w-3 h-3 rounded-full bg-red-600 inline-block"></span> Etiqueta Roja (Inseguro)</div>
                  <div className="flex items-center gap-2 mb-1"><span className="w-3 h-3 rounded-full bg-yellow-500 inline-block"></span> Etiqueta Amarilla (Restringido)</div>
                  <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-green-500 inline-block"></span> Etiqueta Verde (Seguro)</div>
               </div>
               {leafletReady && (
                 <MapComponent cases={cases} onSelectCase={setSelectedCase} />
               )}
            </div>
            
            <div className="w-full lg:w-96 bg-white rounded-xl shadow-sm border border-slate-200 overflow-y-auto shrink-0">
              <CaseDetailsSidebar selectedCase={selectedCase} />
            </div>
          </div>
        ) : (
          <CasesList cases={cases} onSelectCase={handleSelectCaseFromList} onEditCase={handleEditCase} onDeleteCase={handleDeleteCase} />
        )}
      </main>

      {isFormOpen && (
        <CaseRegistrationModal 
          key={editingCaseId || 'new'}
          onClose={() => { setIsFormOpen(false); setEditingCaseId(null); }} 
          onSave={handleSaveCase} 
          leafletReady={leafletReady}
          initialData={editingCaseId ? cases.find(c => c.id === editingCaseId) || null : null}
        />
      )}
    </div>
  );
}

// --- LISTA DE CASOS CON FILTROS ---
function CasesList({ cases, onSelectCase, onEditCase, onDeleteCase }: { cases: any[], onSelectCase: (c: any) => void, onEditCase: (c: any) => void, onDeleteCase: (c: any) => void }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMunicipio, setFilterMunicipio] = useState('');
  const [filterDano, setFilterDano] = useState('');
  
  const filteredCases = useMemo(() => {
    return cases.filter((c: any) => {
      const matchSearch = c.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.propietario.cedula.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.propietario.nombres.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.propietario.apellidos.toLowerCase().includes(searchTerm.toLowerCase());
      const matchMunicipio = filterMunicipio ? c.ubicacion.municipio === filterMunicipio : true;
      const matchDano = filterDano ? c.categoriaDano === filterDano : true;
      
      return matchSearch && matchMunicipio && matchDano;
    });
  }, [cases, searchTerm, filterMunicipio, filterDano]);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden fade-in">
      <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row gap-4 items-center justify-between">
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <List className="w-5 h-5 text-slate-500" />
          Directorio de Casos Registrados
        </h2>
        
        <div className="flex flex-col sm:flex-row w-full md:w-auto gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Buscar por ID, Cédula o Nombre..." 
              className="pl-9 pr-4 py-2 border border-slate-300 rounded-md text-sm w-full sm:w-64 focus:ring-red-500 focus:border-red-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <Filter className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <select 
                className="pl-9 pr-4 py-2 border border-slate-300 rounded-md text-sm w-full focus:ring-red-500"
                value={filterMunicipio}
                onChange={(e) => setFilterMunicipio(e.target.value)}
              >
                <option value="">Todos los Municipios</option>
                {MUNICIPIOS_YARACUY.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
            
            <select 
              className="px-4 py-2 border border-slate-300 rounded-md text-sm flex-1 sm:flex-none focus:ring-red-500"
              value={filterDano}
              onChange={(e) => setFilterDano(e.target.value)}
            >
              <option value="">Cualquier Etiqueta</option>
              <option value="Roja">Inhabitable </option>
              <option value="Amarilla">Restringida </option>
              <option value="Verde">Habitable (daño leve) </option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-slate-600 uppercase bg-slate-100 border-b border-slate-200">
            <tr>
              <th className="px-6 py-4">ID de Caso</th>
              <th className="px-6 py-4">Ubicación</th>
              <th className="px-6 py-4">Responsable</th>
              <th className="px-6 py-4">Estructura</th>
              <th className="px-6 py-4">Clasificación ATC-20</th>
              <th className="px-6 py-4 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filteredCases.length > 0 ? (
              filteredCases.map((c: any) => (
                <tr key={c.id} className="bg-white border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-bold text-slate-900 whitespace-nowrap">{c.id}</td>
                  <td className="px-6 py-4">
                    <span className="font-semibold block">{c.ubicacion.municipio}</span>
                    <span className="text-slate-500 text-xs">{c.ubicacion.sector}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="block">{c.propietario.nombres} {c.propietario.apellidos}</span>
                    <span className="text-slate-500 text-xs">{c.propietario.cedula}</span>
                  </td>
                  <td className="px-6 py-4">{c.tipoInfraestructura}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${
                      c.categoriaDano === 'Roja' ? 'bg-red-100 text-red-800 border-red-200' :
                      c.categoriaDano === 'Amarilla' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                      'bg-green-100 text-green-800 border-green-200'
                    }`}>
                      Etiqueta {c.categoriaDano}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button 
                        onClick={() => onSelectCase(c)}
                        className="text-indigo-600 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 p-2 rounded transition-colors inline-flex items-center"
                        title="Ver en Mapa"
                      >
                        <MapPin className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => onEditCase(c)}
                        className="text-amber-600 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 p-2 rounded transition-colors inline-flex items-center"
                        title="Editar Caso"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => onDeleteCase(c)}
                        className="text-red-600 hover:text-red-900 bg-red-50 hover:bg-red-100 p-2 rounded transition-colors inline-flex items-center"
                        title="Eliminar Caso"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                  <Search className="w-10 h-10 mx-auto text-slate-300 mb-3" />
                  <p className="text-base font-medium text-slate-600">No se encontraron casos</p>
                  <p className="text-sm">Intenta ajustar los filtros de búsqueda.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 border-t border-slate-200 bg-slate-50 text-xs text-slate-500 text-right">
        Mostrando {filteredCases.length} registro(s)
      </div>
    </div>
  );
}

// --- COMPONENTES RESTANTES ---

function DashboardStats({ cases }: { cases: any[] }) {
  const stats = useMemo(() => {
    const total = cases.length;
    const etiquetaRoja = cases.filter((c: any) => c.categoriaDano === 'Roja').length;
    const etiquetaAmarilla = cases.filter((c: any) => c.categoriaDano === 'Amarilla').length;
    const etiquetaVerde = cases.filter((c: any) => c.categoriaDano === 'Verde').length;
    const conInspeccion = cases.filter((c: any) => c.inspeccion.realizada === 'si').length;
    const sinInspeccion = cases.filter((c: any) => c.inspeccion.realizada === 'no').length;

    const municipiosCount = cases.reduce((acc: any, curr: any) => {
      acc[curr.ubicacion.municipio] = (acc[curr.ubicacion.municipio] || 0) + 1;
      return acc;
    }, {});
    
    let maxMuni = 'N/A';
    let maxCount = 0;
    
    for (const [muni, count] of Object.entries(municipiosCount) as [string, number][]) {
      if (count > maxCount) {
        maxCount = count;
        maxMuni = muni;
      }
    }

    return { total, etiquetaRoja, etiquetaAmarilla, etiquetaVerde, conInspeccion, sinInspeccion, maxMuni };
  }, [cases]);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-center">
        <span className="text-slate-500 text-sm font-semibold">Total Casos Afectados</span>
        <span className="text-3xl font-bold text-slate-800">{stats.total}</span>
        <div className="mt-2 flex text-xs gap-2">
          <span className="text-red-600 font-medium">{stats.etiquetaRoja} Inhabitable</span> •
          <span className="text-yellow-600 font-medium">{stats.etiquetaAmarilla} Restringida</span> •
          <span className="text-green-600 font-medium">{stats.etiquetaVerde} Habitable</span>
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-center">
        <span className="text-slate-500 text-sm font-semibold">Estado de Inspecciones</span>
        <div className="flex justify-between items-end mt-1">
          <div>
            <span className="text-2xl font-bold text-emerald-600">{stats.conInspeccion}</span>
            <span className="text-xs text-slate-500 block">Inspeccionados</span>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold text-amber-600">{stats.sinInspeccion}</span>
            <span className="text-xs text-slate-500 block">Pendientes</span>
          </div>
        </div>
      </div>

      <div className="bg-red-50 p-4 rounded-xl shadow-sm border border-red-100 flex flex-col justify-center">
        <span className="text-red-800 text-sm font-semibold flex items-center gap-1">
          <AlertTriangle className="w-4 h-4" /> Alerta Máxima
        </span>
        <span className="text-3xl font-bold text-red-600">{stats.etiquetaRoja}</span>
        <span className="text-xs text-red-700 mt-1">Estructuras colapsadas (Inseguras)</span>
      </div>

      <div className="bg-indigo-50 p-4 rounded-xl shadow-sm border border-indigo-100 flex flex-col justify-center">
        <span className="text-indigo-800 text-sm font-semibold flex items-center gap-1">
          <MapPin className="w-4 h-4" /> Municipio Más Afectado
        </span>
        <span className="text-2xl font-bold text-indigo-700 mt-1 truncate">{stats.maxMuni}</span>
        <span className="text-xs text-indigo-600 mt-1">Basado en reportes actuales</span>
      </div>
    </div>
  );
}

interface MapComponentProps {
  cases: any[];
  onSelectCase: (caseItem: any) => void;
}

function MapComponent({ cases, onSelectCase }: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<any>(null);
  const markersLayer = useRef<any>(null);

  useEffect(() => {
    if (!window.L || !mapRef.current) return;

    if (!leafletMap.current) {
      const yaracuyBounds = window.L.latLngBounds([
        [9.70, -69.40], 
        [10.85, -68.15] 
      ]);

      leafletMap.current = window.L.map(mapRef.current, {
        maxBounds: yaracuyBounds,
        maxBoundsViscosity: 1.0,
        minZoom: 9
      }).setView([10.3333, -68.7333], 9);

      window.L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        attribution: '&copy; Google',
        maxZoom: 19
      }).addTo(leafletMap.current);
      
      fetch('https://nominatim.openstreetmap.org/search?state=Yaracuy&country=Venezuela&polygon_geojson=1&format=json')
        .then(res => res.json())
        .then(data => {
          if (data && data.length > 0) {
            const geojson = data[0].geojson;
            window.L.geoJSON(geojson, {
              style: { color: '#ef4444', weight: 3, fill: false }
            }).addTo(leafletMap.current);

            const worldCoords = [ [-90, -180], [90, -180], [90, 180], [-90, 180] ];
            let holes: any[] = [];
            
            if (geojson.type === 'Polygon') {
              holes.push(geojson.coordinates[0].map((c: any) => [c[1], c[0]]));
            } else if (geojson.type === 'MultiPolygon') {
              geojson.coordinates.forEach((poly: any) => {
                holes.push(poly[0].map((c: any) => [c[1], c[0]]));
              });
            }
            
            window.L.polygon([worldCoords, ...holes], {
              color: 'transparent',
              fillColor: '#000000',
              fillOpacity: 0.7
            }).addTo(leafletMap.current);
          }
        })
        .catch(err => console.error("Error al cargar la frontera de Yaracuy:", err));

      markersLayer.current = window.L.layerGroup().addTo(leafletMap.current);
    }

    if (markersLayer.current) {
      markersLayer.current.clearLayers();
    }
    
    cases.forEach((c: any) => {
      const lat = c?.coordenadas?.lat !== undefined ? parseFloat(c.coordenadas.lat) : NaN;
      const lng = c?.coordenadas?.lng !== undefined ? parseFloat(c.coordenadas.lng) : NaN;

      if (
        isNaN(lat) || 
        isNaN(lng) || 
        lat < -90 || 
        lat > 90 || 
        lng < -180 || 
        lng > 180 ||
        (lat === 0 && lng === 0) 
      ) {
        console.warn(
          `⚠️ Caso omitido en el mapa por coordenadas geográficamente inválidas [ID: ${c?.id || 'Desconocido'}]:`, 
          c?.coordenadas
        );
        return; 
      }

      let color = '#22c55e'; // Verde por defecto
      if (c.categoriaDano === 'Amarilla') color = '#eab308'; // Amarilla
      if (c.categoriaDano === 'Roja') color = '#ef4444'; // Roja

      try {
        const marker = window.L.circleMarker([lat, lng], {
          radius: 8,
          fillColor: color,
          color: '#ffffff',
          weight: 2,
          opacity: 1,
          fillOpacity: 0.9
        });

        marker.on('click', () => {
          onSelectCase(c);
        });
        
        const municipio = c?.ubicacion?.municipio || 'Sin municipio';
        const categoria = c?.categoriaDano || 'Sin categoría';
        marker.bindTooltip(`<b>${c.id || 'S/I'}</b><br/>${municipio} - Etiqueta ${categoria}`, { direction: 'top' });
        
        if (markersLayer.current) {
          marker.addTo(markersLayer.current);
        }
      } catch (markerError) {
        console.error(`Error crítico de Leaflet al intentar renderizar el caso ${c?.id}:`, markerError);
      }
    });

  }, [cases, onSelectCase]);

  return <div ref={mapRef} className="w-full h-full z-0" />;
}

function CaseDetailsSidebar({ selectedCase }: { selectedCase: any }) {
  if (!selectedCase) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-400 p-6 text-center">
        <MapPin className="w-16 h-16 mb-4 text-slate-300" />
        <p>Seleccione un punto en el mapa para ver los detalles del caso registrado.</p>
      </div>
    );
  }

  const badgeColor = 
    selectedCase.categoriaDano === 'Roja' ? 'bg-red-100 text-red-800 border-red-200' :
    selectedCase.categoriaDano === 'Amarilla' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
    'bg-green-100 text-green-800 border-green-200';

  const estadoUso = 
    selectedCase.categoriaDano === 'Roja' ? 'Inseguro (Peligro Inminente)' :
    selectedCase.categoriaDano === 'Amarilla' ? 'Uso Restringido (Precaución)' :
    'Inspeccionado (Seguro)';

  return (
    <div className="flex flex-col h-full">
      <div className="relative h-48 bg-slate-200 shrink-0">
        {selectedCase.fotos && selectedCase.fotos.length > 0 ? (
          <img src={selectedCase.fotos[0]} alt="Infraestructura afectada" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-400">
            <Camera className="w-10 h-10" />
          </div>
        )}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 pt-12">
          <h2 className="text-white font-bold text-lg">{selectedCase.id}</h2>
          <p className="text-slate-200 text-sm flex items-center gap-1">
            <MapPin className="w-3 h-3" /> {selectedCase.ubicacion.municipio}, {selectedCase.ubicacion.sector}
          </p>
        </div>
      </div>

      <div className="p-4 overflow-y-auto flex-grow space-y-6">
        <section>
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-slate-500" /> Evaluación ATC-20
            </h3>
            <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${badgeColor}`}>
              Etiqueta {selectedCase.categoriaDano}
            </span>
          </div>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm space-y-2">
            <p><span className="text-slate-500">Condición:</span> <span className="font-bold">{estadoUso}</span></p>
            <p><span className="text-slate-500">Tipo Estructura:</span> <span className="font-medium">{selectedCase.tipoInfraestructura}</span></p>
            <p><span className="text-slate-500">Afectación:</span> <span className="font-medium capitalize">{selectedCase.tipoAfectacion.replace(/_/g, ' ')}</span></p>
            <p><span className="text-slate-500">Inspección:</span> <span className="font-medium">
              {selectedCase.inspeccion.realizada === 'si' ? `Sí, por ${selectedCase.inspeccion.organo} (${selectedCase.inspeccion.funcionario || 'N/A'})` : 'Pendiente'}
            </span></p>
          </div>
        </section>

        <section>
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2 mb-2">
            <Home className="w-4 h-4 text-slate-500" /> Responsable Principal
          </h3>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm space-y-2">
            <p className="font-semibold text-slate-800">{selectedCase.propietario.nombres} {selectedCase.propietario.apellidos}</p>
            <p><span className="text-slate-500">CI:</span> {selectedCase.propietario.cedula}</p>
            <p><span className="text-slate-500">Teléfono:</span> {selectedCase.propietario.telefono}</p>
            <p><span className="text-slate-500">Estatus:</span> <span className="capitalize">{selectedCase.propietario.estatusRefugio.replace(/_/g, ' ')}</span></p>
            {(selectedCase.propietario.dano || selectedCase.propietario.medicina || selectedCase.propietario.requiereAsistenciaMedica) && (
              <div className="mt-2 pt-2 border-t border-red-200 text-xs bg-red-50 p-2 rounded">
                {selectedCase.propietario.dano && <p><span className="text-red-800 font-semibold">Lesión:</span> <span className="text-red-700">{selectedCase.propietario.dano}</span></p>}
                {selectedCase.propietario.medicina && <p><span className="text-red-800 font-semibold">Requiere:</span> <span className="text-red-700">{selectedCase.propietario.medicina}</span></p>}
                {selectedCase.propietario.requiereAsistenciaMedica && <p className="text-red-600 font-bold mt-1">⚠️ Requiere Asistencia Médica Inmediata</p>}
              </div>
            )}
          </div>
        </section>

        <section>
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2 mb-2">
            <Users className="w-4 h-4 text-slate-500" /> Familiares / Habitantes ({(selectedCase.habitantes || []).length})
          </h3>
          {selectedCase.habitantes && selectedCase.habitantes.length > 0 ? (
            <div className="space-y-2">
              {selectedCase.habitantes.map((hab: any, idx: number) => (
                <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm">
                  <p className="font-semibold">{hab.nombres} {hab.apellidos} <span className="text-xs text-slate-500 font-normal">CI: {hab.cedula}</span></p>
                  {(hab.dano || hab.medicina || hab.requiereAsistenciaMedica) && (
                    <div className="mt-1 pt-1 border-t border-slate-200 text-xs">
                      {hab.dano && <p><span className="text-slate-500">Afección:</span> <span className="text-red-600">{hab.dano}</span></p>}
                      {hab.medicina && <p><span className="text-slate-500">Requiere/Asistencia:</span> {hab.medicina}</p>}
                      {hab.requiereAsistenciaMedica && <p className="text-red-600 font-bold mt-1">⚠️ Requiere Asistencia Médica Inmediata</p>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-500 italic">No se registraron otros habitantes.</p>
          )}
        </section>

      </div>
    </div>
  );
}

function CaseRegistrationModal({ onClose, onSave, leafletReady, initialData }: { onClose: () => void, onSave: (casos: any) => void, leafletReady: boolean, initialData?: any | null }) {
  const getInitialInfraestructuras = () => {
    if (initialData) {
      return [{
        tipoInfraestructura: initialData.tipoInfraestructura || 'Casa',
        tipoAfectacion: initialData.tipoAfectacion || 'grieta_superficial',
        ubicacion: initialData.ubicacion || { municipio: 'San Felipe', sector: '', calle: '', numero: '' },
        inspeccion: initialData.inspeccion || { realizada: 'no', organo: '', funcionario: '' },
        coordenadas: initialData.coordenadas || { lat: 10.3396, lng: -68.7351 },
        fotos: initialData.fotos || []
      }];
    }
    return [{
      tipoInfraestructura: 'Casa',
      tipoAfectacion: 'grieta_superficial',
      ubicacion: { municipio: 'San Felipe', sector: '', calle: '', numero: '' },
      inspeccion: { realizada: 'no', organo: '', funcionario: '' },
      coordenadas: { lat: 10.3396, lng: -68.7351 },
      fotos: []
    }];
  };

  const getInitialPropietario = () => {
    if (initialData?.propietario) {
      const p = initialData.propietario;
      const cedulaMatch = (p.cedula || '').match(/^([VE])-(\d+)$/);
      return {
        nombres: p.nombres || '',
        apellidos: p.apellidos || '',
        nacionalidad: cedulaMatch ? cedulaMatch[1] : 'V',
        cedula: cedulaMatch ? cedulaMatch[2] : (p.cedula || '').replace(/^[VE]-/, ''),
        telefono: p.telefono || '',
        correo: p.correo || '',
        estatusRefugio: p.estatusRefugio || 'sin_necesidad',
        dano: p.dano || '',
        medicina: p.medicina || '',
        requiereAsistenciaMedica: p.requiereAsistenciaMedica || false
      };
    }
    return { 
      nombres: '', apellidos: '', nacionalidad: 'V', cedula: '', telefono: '', correo: '', 
      estatusRefugio: 'sin_necesidad', dano: '', medicina: '', requiereAsistenciaMedica: false 
    };
  };

  const getInitialOtrosHabitantes = () => {
    if (initialData?.habitantes && initialData.habitantes.length > 0) {
      return initialData.habitantes.map((h: any) => ({
        nombres: h.nombres || '',
        apellidos: h.apellidos || '',
        nacionalidad: 'V',
        cedula: (h.cedula || '').replace(/^[VE]-/, ''),
        dano: h.dano || '',
        medicina: h.medicina || '',
        requiereAsistenciaMedica: h.requiereAsistenciaMedica || false
      }));
    }
    return [];
  };

  const [infraestructuras, setInfraestructuras] = useState<any[]>(getInitialInfraestructuras);
  const [propietario, setPropietario] = useState(getInitialPropietario);
  const [nucleoFamiliar, setNucleoFamiliar] = useState<any[]>([]);
  const [otrosHabitantes, setOtrosHabitantes] = useState<any[]>(getInitialOtrosHabitantes);

  const getEstructuraConfig = (tipo: string) => {
    switch (tipo) {
      case 'Local Comercial': return { title: 'Datos del Propietario', showFamilia: false, showOtros: false };
      case 'Institución del estado': return { title: 'Directivo o funcionario responsable', showFamilia: false, showOtros: false };
      case 'Institución educativa': return { title: 'Director o Responsable', showFamilia: false, showOtros: false };
      case 'Conjunto residencial': return { title: 'Jefe de Condominio', showFamilia: true, showOtros: true };
      default: return { title: 'Datos del Propietario o Responsable', showFamilia: true, showOtros: true };
    }
  };

  const currentConfig = getEstructuraConfig(infraestructuras[0].tipoInfraestructura);

  const handleInfraChange = (index: number, section: string | null, field: string, value: any) => {
    const newInfras = [...infraestructuras];
    if (section) {
      newInfras[index] = { ...newInfras[index], [section]: { ...newInfras[index][section], [field]: value } };
    } else {
      newInfras[index] = { ...newInfras[index], [field]: value };
    }
    setInfraestructuras(newInfras);
  };

  const handleAddInfraestructura = () => {
    setInfraestructuras([...infraestructuras, {
      tipoInfraestructura: infraestructuras[0].tipoInfraestructura,
      tipoAfectacion: 'grieta_superficial',
      ubicacion: { ...infraestructuras[0].ubicacion },
      inspeccion: { realizada: 'no', organo: '', funcionario: '' },
      coordenadas: { ...infraestructuras[0].coordenadas }, 
      fotos: []
    }]);
  };

  const removeInfra = (index: number) => {
    const newInfras = [...infraestructuras];
    newInfras.splice(index, 1);
    setInfraestructuras(newInfras);
  };

  const handlePropietarioChange = (field: string, value: any) => {
    setPropietario(prev => ({ ...prev, [field]: value }));
  };

  const handleAddFamiliar = () => {
    setNucleoFamiliar([...nucleoFamiliar, { 
      nombres: '', apellidos: '', nacionalidad: 'V', cedula: '', telefono: '', correo: '', 
      filiacion: 'Conyuge o Concubino/a', filiacionOtro: '', afectacion: 'ninguna', afectacionOtro: '',
      asistenciaMedica: false, asistenciaPsicologica: false, requiereMedicinas: false, medicinasDetalle: '',
      requiereAyudaTecnica: false, ayudaTecnicaDetalle: ''
    }]);
  };

  const handleFamiliarChange = (index: number, field: string, value: any) => {
    const newFam = [...nucleoFamiliar];
    newFam[index][field] = value;
    setNucleoFamiliar(newFam);
  };

  const removeFamiliar = (index: number) => {
    const newFam = [...nucleoFamiliar];
    newFam.splice(index, 1);
    setNucleoFamiliar(newFam);
  };

  const handleAddOtroHabitante = () => {
    setOtrosHabitantes([...otrosHabitantes, { nombres: '', apellidos: '', nacionalidad: 'V', cedula: '', dano: '', medicina: '', requiereAsistenciaMedica: false }]);
  };

  const handleOtroHabitanteChange = (index: number, field: string, value: any) => {
    const newOtros = [...otrosHabitantes];
    newOtros[index][field] = value;
    setOtrosHabitantes(newOtros);
  };

  const removeOtroHabitante = (index: number) => {
    const newOtros = [...otrosHabitantes];
    newOtros.splice(index, 1);
    setOtrosHabitantes(newOtros);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    
    const allHabitantes: any[] = [];
    
    if (currentConfig.showFamilia) {
      nucleoFamiliar.forEach(h => {
        allHabitantes.push({
          nombres: h.nombres,
          apellidos: h.apellidos,
          cedula: h.nacionalidad !== 'no posee' ? `${h.nacionalidad}-${h.cedula}` : 'Sin Cédula',
          dano: h.afectacion === 'otro' ? h.afectacionOtro : (h.afectacion === 'ninguna' ? '' : h.afectacion),
          medicina: (h.requiereMedicinas ? `Medicina: ${h.medicinasDetalle} ` : '') + (h.requiereAyudaTecnica ? `| Ayuda Téc: ${h.ayudaTecnicaDetalle}` : '') + (h.asistenciaPsicologica ? ' | Req. Apoyo Psicológico' : ''),
          requiereAsistenciaMedica: h.asistenciaMedica
        });
      });
      otrosHabitantes.forEach(h => {
        allHabitantes.push({
          nombres: h.nombres,
          apellidos: h.apellidos,
          cedula: h.nacionalidad !== 'no posee' ? `${h.nacionalidad}-${h.cedula}` : 'Sin Cédula',
          dano: h.dano,
          medicina: h.medicina,
          requiereAsistenciaMedica: h.requiereAsistenciaMedica
        });
      });
    }

    const formattedPropietario = {
      ...propietario,
      cedula: propietario.nacionalidad !== 'no posee' ? `${propietario.nacionalidad}-${propietario.cedula}` : 'Sin Cédula'
    };

    const casosToSave = infraestructuras.map(infra => {
      const afectacionData = TIPOS_AFECTACION.find(t => t.id === infra.tipoAfectacion);
      const categoriaDano = afectacionData ? afectacionData.categoria : 'Verde';
      
      return {
        ...infra,
        categoriaDano,
        propietario: formattedPropietario,
        habitantes: allHabitantes
      };
    });

    onSave(casosToSave);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden fade-in">
        
        <div className="flex justify-between items-center p-4 border-b border-slate-100 bg-slate-50">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <FileText className="w-5 h-5 text-red-600" />
            {initialData ? 'Editar Caso' : 'Registro de Infraestructura Afectada'}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-full p-1 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 flex-grow bg-white">
          <form id="registro-form" onSubmit={handleSubmit} className="space-y-8">
            
            {/* SECCIÓN ÚNICA UNIFICADA: DATOS DE LA INFRAESTRUCTURA */}
            <section className="space-y-6">
              <div className="flex justify-between items-center border-b pb-2">
                <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                  <Home className="w-5 h-5 text-slate-500" /> Datos de la Infraestructura
                </h3>
                <button type="button" onClick={handleAddInfraestructura} className="bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1 transition-colors">
                  <Plus className="w-4 h-4" /> Añadir Infraestructura
                </button>
              </div>

              {infraestructuras.map((infra, index) => (
                <div key={index} className="p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-6 relative shadow-sm">
                  {index > 0 && (
                    <button type="button" onClick={() => removeInfra(index)} className="absolute top-3 right-3 text-red-500 hover:text-red-700 bg-red-50 p-1 rounded-md">
                      <X className="w-5 h-5" />
                    </button>
                  )}
                  <h4 className="font-bold text-slate-700 text-md">Registro de Infraestructura #{index + 1}</h4>
                  
                  {/* Datos Básicos y Daño */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Tipo de Infraestructura</label>
                      <select 
                        className="w-full p-2 border border-slate-300 rounded-md focus:ring-red-500 focus:border-red-500"
                        value={infra.tipoInfraestructura}
                        onChange={(e) => handleInfraChange(index, null, 'tipoInfraestructura', e.target.value)}
                      >
                        <option value="Casa">Casa</option>
                        <option value="Apartamento">Apartamento</option>
                        <option value="Edificio">Edificio</option>
                        <option value="Conjunto residencial">Conjunto residencial</option>
                        <option value="Local Comercial">Local Comercial</option>
                        <option value="Institución del estado">Institución del estado</option>
                        <option value="Institución educativa">Institución educativa</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Evaluación Visual ATC-20</label>
                      <select 
                        className="w-full p-2 border border-slate-300 rounded-md focus:ring-red-500 focus:border-red-500"
                        value={infra.tipoAfectacion}
                        onChange={(e) => handleInfraChange(index, null, 'tipoAfectacion', e.target.value)}
                      >
                        {TIPOS_AFECTACION.map(t => (
                          <option key={t.id} value={t.id}>{t.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Inspección */}
                  <div className="p-4 bg-white rounded-lg border border-slate-200 space-y-4">
                    <p className="text-sm font-medium text-slate-700">Estado de Inspección Oficial</p>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2">
                        <input type="radio" name={`inspeccion-${index}`} value="si" checked={infra.inspeccion.realizada === 'si'} onChange={() => handleInfraChange(index, 'inspeccion', 'realizada', 'si')} />
                        Con Inspección
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="radio" name={`inspeccion-${index}`} value="no" checked={infra.inspeccion.realizada === 'no'} onChange={() => handleInfraChange(index, 'inspeccion', 'realizada', 'no')} />
                        Sin Inspección
                      </label>
                    </div>
                    {infra.inspeccion.realizada === 'si' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Órgano Inspector</label>
                          <select 
                            className="w-full p-2 border border-slate-300 rounded-md"
                            value={infra.inspeccion.organo}
                            onChange={(e) => handleInfraChange(index, 'inspeccion', 'organo', e.target.value)}
                            required
                          >
                            <option value="">Seleccione...</option>
                            <option value="Protección Civil">Protección Civil</option>
                            <option value="Bomberos">Bomberos</option>
                            <option value="CICPC">CICPC</option>
                            <option value="Gobernación/Alcaldía">Ingeniería Municipal</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Funcionario que realizó la inspección</label>
                          <input 
                            type="text" 
                            className="w-full p-2 border border-slate-300 rounded-md"
                            placeholder="Nombre y Apellido"
                            value={infra.inspeccion.funcionario}
                            onChange={(e) => handleInfraChange(index, 'inspeccion', 'funcionario', e.target.value)}
                            required
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Ubicación */}
                  <div className="pt-2 border-t border-slate-200 space-y-4">
                    <h5 className="text-sm font-bold text-slate-700 flex items-center gap-1"><MapPin className="w-4 h-4"/> Ubicación Exacta</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Municipio</label>
                        <select 
                          className="w-full p-2 border border-slate-300 rounded-md"
                          value={infra.ubicacion.municipio}
                          onChange={(e) => handleInfraChange(index, 'ubicacion', 'municipio', e.target.value)}
                        >
                          {MUNICIPIOS_YARACUY.map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Sector / Urbanización</label>
                        <input type="text" className="w-full p-2 border border-slate-300 rounded-md" required
                          value={infra.ubicacion.sector} onChange={(e) => handleInfraChange(index, 'ubicacion', 'sector', e.target.value)} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Calle / Avenida</label>
                        <input type="text" className="w-full p-2 border border-slate-300 rounded-md" required
                          value={infra.ubicacion.calle} onChange={(e) => handleInfraChange(index, 'ubicacion', 'calle', e.target.value)} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Nro (Casa/Apto/Local)</label>
                        <input type="text" className="w-full p-2 border border-slate-300 rounded-md" required
                          value={infra.ubicacion.numero} onChange={(e) => handleInfraChange(index, 'ubicacion', 'numero', e.target.value)} />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Seleccionar en el Mapa (Clic o arrastre el marcador)</label>
                      <div className="h-56 bg-slate-200 rounded-lg border border-slate-300 relative overflow-hidden">
                        {leafletReady ? (
                          <FormMapPicker 
                            coordenadas={infra.coordenadas} 
                            onChange={(coords) => handleInfraChange(index, null, 'coordenadas', coords)} 
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full text-slate-500">Cargando mapa...</div>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-1">Lat: {infra.coordenadas.lat.toFixed(4)}, Lng: {infra.coordenadas.lng.toFixed(4)}</p>
                    </div>
                  </div>

                  {/* Evidencia */}
                  <div className="pt-2 border-t border-slate-200">
                    <h5 className="text-sm font-bold text-slate-700 flex items-center gap-1 mb-3"><Camera className="w-4 h-4"/> Evidencia Fotográfica</h5>
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center hover:bg-white transition-colors bg-white">
                      <Camera className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-sm text-slate-600 mb-3">Adjunte fotografías que evidencien el daño de esta infraestructura</p>
                      <label className="bg-slate-800 text-white px-4 py-2 rounded-md cursor-pointer hover:bg-slate-700 inline-block text-sm">
                        Seleccionar Archivos
                        <input type="file" className="hidden" multiple accept="image/*" onChange={(e) => {
                          const files = Array.from(e.target.files || []);
                          const urls = files.map(f => URL.createObjectURL(f));
                          handleInfraChange(index, null, 'fotos', [...infra.fotos, ...urls]);
                          e.target.value = '';
                        }} />
                      </label>
                    </div>
                    {infra.fotos.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        {infra.fotos.map((foto: string, i: number) => (
                          <div key={i} className="relative w-24 h-24 rounded-lg overflow-hidden border border-slate-300 group">
                            <img src={foto} alt={`Evidencia ${i + 1}`} className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => {
                                const nuevas = infra.fotos.filter((_: any, j: number) => j !== i);
                                URL.revokeObjectURL(foto);
                                handleInfraChange(index, null, 'fotos', nuevas);
                              }}
                              className="absolute top-1 right-1 bg-black/60 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                </div>
              ))}
            </section>

            {/* SECCIÓN DEL PROPIETARIO / RESPONSABLE */}
            <section className="space-y-4 pt-4">
              <h3 className="text-lg font-semibold text-slate-800 border-b pb-2 flex items-center gap-2">
                <Users className="w-5 h-5 text-slate-500" /> {currentConfig.title}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nombres</label>
                  <input type="text" className="w-full p-2 border border-slate-300 rounded-md" required
                    value={propietario.nombres} onChange={(e) => handlePropietarioChange('nombres', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Apellidos</label>
                  <input type="text" className="w-full p-2 border border-slate-300 rounded-md" required
                    value={propietario.apellidos} onChange={(e) => handlePropietarioChange('apellidos', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Cédula de Identidad</label>
                  <div className="flex gap-2">
                    <select 
                      className="w-1/3 p-2 border border-slate-300 rounded-md"
                      value={propietario.nacionalidad}
                      onChange={(e) => handlePropietarioChange('nacionalidad', e.target.value)}
                    >
                      <option value="V">V</option>
                      <option value="E">E</option>
                      <option value="no posee">No posee</option>
                    </select>
                    {propietario.nacionalidad !== 'no posee' && (
                      <input type="number" className="w-2/3 p-2 border border-slate-300 rounded-md" required
                        value={propietario.cedula} onChange={(e) => handlePropietarioChange('cedula', e.target.value)} />
                    )}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Teléfono <span className="text-red-500">*</span></label>
                  <input type="text" className="w-full p-2 border border-slate-300 rounded-md" required
                    value={propietario.telefono} onChange={(e) => handlePropietarioChange('telefono', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Correo Electrónico <span className="text-red-500">*</span></label>
                  <input type="email" className="w-full p-2 border border-slate-300 rounded-md" required
                    value={propietario.correo} onChange={(e) => handlePropietarioChange('correo', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Situación de Refugio</label>
                  <select 
                    className="w-full p-2 border border-slate-300 rounded-md"
                    value={propietario.estatusRefugio}
                    onChange={(e) => handlePropietarioChange('estatusRefugio', e.target.value)}
                  >
                    <option value="sin_necesidad">Sin Necesidad de Refugio</option>
                    <option value="sin_refugio">Requiere Refugio (No asignado)</option>
                    <option value="en_refugio">En Refugio Asignado</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 p-4 bg-red-50 border border-red-100 rounded-lg">
                <h4 className="md:col-span-2 text-sm font-bold text-red-800">Estado de Salud / Afectación del Responsable</h4>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Daño/Lesión Sufrida (Opcional)</label>
                  <input type="text" placeholder="Ej. Fractura, Corte..." className="w-full p-2 border border-slate-300 rounded-md"
                    value={propietario.dano || ''} onChange={(e) => handlePropietarioChange('dano', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Requiere Medicina/Ayuda Técnica</label>
                  <input type="text" placeholder="Ej. Insulina, Silla de ruedas..." className="w-full p-2 border border-slate-300 rounded-md"
                    value={propietario.medicina || ''} onChange={(e) => handlePropietarioChange('medicina', e.target.value)} />
                </div>
                <div className="md:col-span-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 text-red-600 rounded focus:ring-red-500" 
                      checked={propietario.requiereAsistenciaMedica || false} 
                      onChange={(e) => handlePropietarioChange('requiereAsistenciaMedica', e.target.checked)} />
                    <span className="text-sm font-bold text-red-700">Requiere Asistencia Médica Inmediata</span>
                  </label>
                </div>
              </div>

              {/* NÚCLEO FAMILIAR (Sección Anidada Condicional) */}
              {currentConfig.showFamilia && (
                <div className="mt-8 pt-6 border-t border-slate-200">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-lg font-bold text-slate-800">Núcleo Familiar</h4>
                    <button type="button" onClick={handleAddFamiliar} className="bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1 border border-blue-200 transition-colors">
                      <Plus className="w-4 h-4" /> Añadir Familiar
                    </button>
                  </div>
                  
                  {nucleoFamiliar.length === 0 && (
                    <p className="text-sm text-slate-500 italic p-4 bg-slate-50 rounded-lg text-center border border-slate-200">
                      Haga clic en "+ Añadir Familiar" para registrar miembros de la familia.
                    </p>
                  )}

                  <div className="space-y-4">
                    {nucleoFamiliar.map((fam, idx) => (
                      <div key={idx} className="p-4 bg-white border border-slate-200 rounded-lg relative shadow-sm">
                        <button type="button" onClick={() => removeFamiliar(idx)} className="absolute top-2 right-2 text-red-500 hover:text-red-700">
                          <X className="w-5 h-5" />
                        </button>
                        <h5 className="text-sm font-bold text-slate-700 mb-3 border-b pb-1">Familiar #{idx + 1}</h5>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Nombres</label>
                            <input type="text" required className="w-full p-2 border border-slate-300 rounded-md text-sm"
                              value={fam.nombres} onChange={(e) => handleFamiliarChange(idx, 'nombres', e.target.value)} />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Apellidos</label>
                            <input type="text" required className="w-full p-2 border border-slate-300 rounded-md text-sm"
                              value={fam.apellidos} onChange={(e) => handleFamiliarChange(idx, 'apellidos', e.target.value)} />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Cédula</label>
                            <div className="flex gap-2">
                              <select className="w-1/3 p-2 border border-slate-300 rounded-md text-sm" value={fam.nacionalidad} onChange={e => handleFamiliarChange(idx, 'nacionalidad', e.target.value)}>
                                <option value="V">V</option>
                                <option value="E">E</option>
                                <option value="no posee">No posee</option>
                              </select>
                              {fam.nacionalidad !== 'no posee' && (
                                <input type="number" className="w-2/3 p-2 border border-slate-300 rounded-md text-sm" 
                                  value={fam.cedula} onChange={e => handleFamiliarChange(idx, 'cedula', e.target.value)} />
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Teléfono (Opcional)</label>
                            <input type="text" className="w-full p-2 border border-slate-300 rounded-md text-sm"
                              value={fam.telefono} onChange={(e) => handleFamiliarChange(idx, 'telefono', e.target.value)} />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Correo (Opcional)</label>
                            <input type="email" className="w-full p-2 border border-slate-300 rounded-md text-sm"
                              value={fam.correo} onChange={(e) => handleFamiliarChange(idx, 'correo', e.target.value)} />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Filiación</label>
                            <select className="w-full p-2 border border-slate-300 rounded-md text-sm" value={fam.filiacion} onChange={(e) => handleFamiliarChange(idx, 'filiacion', e.target.value)}>
                              <option value="Conyuge o Concubino/a">Conyuge o Concubino/a</option>
                              <option value="Hijo o hija">Hijo o hija</option>
                              <option value="Papá">Papá</option>
                              <option value="mamá">Mamá</option>
                              <option value="tío">Tío</option>
                              <option value="tía">Tía</option>
                              <option value="primo">Primo</option>
                              <option value="prima">Prima</option>
                              <option value="yerno">Yerno</option>
                              <option value="yerna">Yerna</option>
                              <option value="cuñado">Cuñado</option>
                              <option value="cuñada">Cuñada</option>
                              <option value="otro">Otro (Especifique)</option>
                            </select>
                            {fam.filiacion === 'otro' && (
                              <input type="text" placeholder="Especifique" className="w-full mt-2 p-2 border border-slate-300 rounded-md text-sm"
                                value={fam.filiacionOtro} onChange={(e) => handleFamiliarChange(idx, 'filiacionOtro', e.target.value)} />
                            )}
                          </div>
                        </div>

                        <div className="p-3 bg-red-50 border border-red-100 rounded-md space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-xs font-bold text-red-800 mb-1">Afectación por el incidente</label>
                              <select className="w-full p-2 border border-slate-300 rounded-md text-sm" value={fam.afectacion} onChange={(e) => handleFamiliarChange(idx, 'afectacion', e.target.value)}>
                                <option value="ninguna">Ninguna</option>
                                <option value="fractura">Fractura</option>
                                <option value="lesiones">Lesiones</option>
                                <option value="politraumatismo">Politraumatismo</option>
                                <option value="traumas psicologicos">Traumas Psicológicos</option>
                                <option value="otro">Otro (Especifique)</option>
                              </select>
                              {fam.afectacion === 'otro' && (
                                <input type="text" placeholder="Especifique" className="w-full mt-2 p-2 border border-slate-300 rounded-md text-sm"
                                  value={fam.afectacionOtro} onChange={(e) => handleFamiliarChange(idx, 'afectacionOtro', e.target.value)} />
                              )}
                            </div>
                            <div className="space-y-2 pt-5">
                               <label className="flex items-center gap-2 cursor-pointer">
                                  <input type="checkbox" className="w-4 h-4 text-red-600 rounded" checked={fam.asistenciaMedica} onChange={e => handleFamiliarChange(idx, 'asistenciaMedica', e.target.checked)} />
                                  <span className="text-xs font-bold text-red-700">Necesita Asistencia Médica Inmediata</span>
                               </label>
                               <label className="flex items-center gap-2 cursor-pointer">
                                  <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" checked={fam.asistenciaPsicologica} onChange={e => handleFamiliarChange(idx, 'asistenciaPsicologica', e.target.checked)} />
                                  <span className="text-xs font-bold text-blue-700">Necesita Asistencia Psicológica</span>
                               </label>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-red-200">
                             <div>
                                <label className="flex items-center gap-2 cursor-pointer mb-1">
                                  <input type="checkbox" className="w-4 h-4" checked={fam.requiereMedicinas} onChange={e => handleFamiliarChange(idx, 'requiereMedicinas', e.target.checked)} />
                                  <span className="text-xs font-semibold">Requiere Medicinas</span>
                                </label>
                                {fam.requiereMedicinas && (
                                  <input type="text" placeholder="Escriba cuáles medicinas" className="w-full p-2 border border-slate-300 rounded-md text-sm" value={fam.medicinasDetalle} onChange={e => handleFamiliarChange(idx, 'medicinasDetalle', e.target.value)} />
                                )}
                             </div>
                             <div>
                                <label className="flex items-center gap-2 cursor-pointer mb-1">
                                  <input type="checkbox" className="w-4 h-4" checked={fam.requiereAyudaTecnica} onChange={e => handleFamiliarChange(idx, 'requiereAyudaTecnica', e.target.checked)} />
                                  <span className="text-xs font-semibold">Necesita Ayuda Técnica</span>
                                </label>
                                {fam.requiereAyudaTecnica && (
                                  <input type="text" placeholder="Escriba cuál ayuda (Ej. Silla de Ruedas)" className="w-full p-2 border border-slate-300 rounded-md text-sm" value={fam.ayudaTecnicaDetalle} onChange={e => handleFamiliarChange(idx, 'ayudaTecnicaDetalle', e.target.value)} />
                                )}
                             </div>
                          </div>
                        </div>

                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>

            {/* OTROS HABITANTES */}
            {currentConfig.showOtros && (
              <section className="space-y-4 pt-4 border-t border-slate-200">
                <div className="flex justify-between items-center pb-2">
                  <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                    <Users className="w-5 h-5 text-slate-500" /> Otros habitantes de la vivienda
                  </h3>
                  <button type="button" onClick={handleAddOtroHabitante} className="text-sm bg-slate-100 text-slate-700 hover:bg-slate-200 px-3 py-1 rounded-md font-medium border border-slate-300">
                    + Añadir Habitante
                  </button>
                </div>
                
                {otrosHabitantes.length === 0 && (
                  <p className="text-sm text-slate-500 italic p-4 bg-slate-50 rounded-lg text-center border border-slate-200">
                    No hay otras personas registradas fuera del núcleo familiar.
                  </p>
                )}

                {otrosHabitantes.map((hab, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 border border-slate-200 rounded-lg relative">
                    <button type="button" onClick={() => removeOtroHabitante(idx)} className="absolute top-2 right-2 text-red-500 hover:text-red-700">
                      <X className="w-5 h-5" />
                    </button>
                    <h4 className="text-sm font-bold text-slate-700 mb-3">Habitante #{idx + 1}</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                      <input type="text" placeholder="Nombres" required className="p-2 border border-slate-300 rounded-md text-sm w-full"
                        value={hab.nombres} onChange={(e) => handleOtroHabitanteChange(idx, 'nombres', e.target.value)} />
                      <input type="text" placeholder="Apellidos" required className="p-2 border border-slate-300 rounded-md text-sm w-full"
                        value={hab.apellidos} onChange={(e) => handleOtroHabitanteChange(idx, 'apellidos', e.target.value)} />
                      <div className="flex gap-2">
                        <select className="w-1/3 p-2 border border-slate-300 rounded-md text-sm" value={hab.nacionalidad} onChange={e => handleOtroHabitanteChange(idx, 'nacionalidad', e.target.value)}>
                           <option value="V">V</option><option value="E">E</option><option value="no posee">No posee</option>
                        </select>
                        {hab.nacionalidad !== 'no posee' && (
                          <input type="number" placeholder="Cédula" className="w-2/3 p-2 border border-slate-300 rounded-md text-sm"
                            value={hab.cedula} onChange={(e) => handleOtroHabitanteChange(idx, 'cedula', e.target.value)} />
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">Daño/Lesión Sufrida (Opcional)</label>
                        <input type="text" placeholder="Ej. Fractura, Corte..." className="p-2 border border-slate-300 rounded-md text-sm w-full"
                          value={hab.dano} onChange={(e) => handleOtroHabitanteChange(idx, 'dano', e.target.value)} />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">Requiere Medicina/Ayuda Técnica</label>
                        <input type="text" placeholder="Ej. Insulina, Silla de ruedas..." className="p-2 border border-slate-300 rounded-md text-sm w-full"
                          value={hab.medicina} onChange={(e) => handleOtroHabitanteChange(idx, 'medicina', e.target.value)} />
                      </div>
                    </div>
                    <div className="mt-3">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="w-4 h-4 text-red-600 rounded focus:ring-red-500" 
                          checked={hab.requiereAsistenciaMedica || false} 
                          onChange={(e) => handleOtroHabitanteChange(idx, 'requiereAsistenciaMedica', e.target.checked)} />
                        <span className="text-xs font-bold text-red-700">Requiere Asistencia Médica Inmediata</span>
                      </label>
                    </div>
                  </div>
                ))}
              </section>
            )}

          </form>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3 z-10">
          <button onClick={onClose} className="px-5 py-2 text-slate-700 bg-white border border-slate-300 rounded-md font-medium hover:bg-slate-50 transition-colors">
            Cancelar
          </button>
          <button type="submit" form="registro-form" className="px-5 py-2 text-white bg-red-600 rounded-md font-medium hover:bg-red-700 transition-colors flex items-center gap-2 shadow-sm">
            <CheckCircle className="w-5 h-5" /> {initialData ? 'Actualizar Caso' : 'Guardar Registro'}
          </button>
        </div>
      </div>
    </div>
  );
}

function FormMapPicker({ coordenadas, onChange }: { coordenadas: { lat: number, lng: number }, onChange: (coords: { lat: number, lng: number }) => void }) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<any>(null);
  const markerRef = useRef<any>(null);

  useEffect(() => {
    if (!window.L || !mapRef.current) return;

    if (!leafletMap.current) {
      const yaracuyBounds = window.L.latLngBounds([
        [9.70, -69.40],
        [10.85, -68.15]
      ]);

      leafletMap.current = window.L.map(mapRef.current, {
        maxBounds: yaracuyBounds,
        maxBoundsViscosity: 1.0,
        minZoom: 9
      }).setView([coordenadas.lat, coordenadas.lng], 12);

      window.L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        attribution: '&copy; Google',
        maxZoom: 19
      }).addTo(leafletMap.current);

      fetch('https://nominatim.openstreetmap.org/search?state=Yaracuy&country=Venezuela&polygon_geojson=1&format=json')
        .then(res => res.json())
        .then(data => {
          if (data && data.length > 0) {
            const geojson = data[0].geojson;
            
            window.L.geoJSON(geojson, {
              style: { color: '#ef4444', weight: 3, fill: false }
            }).addTo(leafletMap.current);

            const worldCoords = [ [-90, -180], [90, -180], [90, 180], [-90, 180] ];
            let holes: any[] = [];
            
            if (geojson.type === 'Polygon') {
              holes.push(geojson.coordinates[0].map((c: any) => [c[1], c[0]]));
            } else if (geojson.type === 'MultiPolygon') {
              geojson.coordinates.forEach((poly: any) => {
                holes.push(poly[0].map((c: any) => [c[1], c[0]]));
              });
            }
            
            window.L.polygon([worldCoords, ...holes], {
              color: 'transparent',
              fillColor: '#000000',
              fillOpacity: 0.7
            }).addTo(leafletMap.current);
          }
        })
        .catch(err => console.error("Error al cargar la frontera de Yaracuy:", err));

      markerRef.current = window.L.marker([coordenadas.lat, coordenadas.lng], { draggable: true }).addTo(leafletMap.current);
      
      if (markerRef.current) {
        markerRef.current.on('dragend', function (event: any) {
          const marker = event.target;
          const position = marker.getLatLng();
          onChange({ lat: position.lat, lng: position.lng });
        });
      }

      if (leafletMap.current) {
        leafletMap.current.on('click', function(e: any) {
          if (markerRef.current) {
            markerRef.current.setLatLng(e.latlng);
          }
          onChange({ lat: e.latlng.lat, lng: e.latlng.lng });
        });
      }
    }

    return () => {
      if (leafletMap.current) {
        leafletMap.current.remove();
        leafletMap.current = null;
      }
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return <div ref={mapRef} className="w-full h-full z-0 cursor-crosshair" />;
}