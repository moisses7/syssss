CREATE TABLE IF NOT EXISTS casos_siged (
    id VARCHAR(50) PRIMARY KEY,
    tipo_infraestructura VARCHAR(100),
    tipo_afectacion VARCHAR(100),
    categoria_dano VARCHAR(50),
    ubicacion JSONB,
    inspeccion JSONB,
    coordenadas JSONB,
    fotos JSONB,
    propietario JSONB,
    habitantes JSONB,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
